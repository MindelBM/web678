/**
[header]
@author ertdfgcvb
@title  Simple output
@desc   The smallest program possible?
*/

export function main() {
	return '?'
}

// Shorter:
// export const main = () => '?'

// Even shorter:
// export let main=o=>'?'

// Shrtst:
// export let main=o=>0
