/**
@module   version.js
@desc     Runner version string
@category core
*/

export default '1.1'
